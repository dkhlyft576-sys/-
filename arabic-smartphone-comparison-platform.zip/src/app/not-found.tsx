import Link from "next/link";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

export default function NotFound() {
  return (
    <>
      <Navbar />
      <main className="flex-1 flex items-center justify-center py-20">
        <div className="text-center px-4">
          <span className="text-7xl mb-6 block">📱</span>
          <h1 className="text-3xl font-extrabold text-gray-900 mb-4">الصفحة غير موجودة</h1>
          <p className="text-gray-500 mb-8">
            عذراً، الصفحة التي تبحث عنها غير موجودة أو تم نقلها
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            <Link
              href="/"
              className="inline-flex items-center gap-2 bg-primary-600 hover:bg-primary-700 text-white font-bold px-6 py-3 rounded-xl transition-colors"
            >
              🏠 الصفحة الرئيسية
            </Link>
            <Link
              href="/search"
              className="inline-flex items-center gap-2 bg-white border border-gray-200 hover:border-primary-300 text-gray-700 font-medium px-6 py-3 rounded-xl transition-colors"
            >
              🔍 البحث عن هاتف
            </Link>
            <Link
              href="/ai-assistant"
              className="inline-flex items-center gap-2 bg-white border border-gray-200 hover:border-primary-300 text-gray-700 font-medium px-6 py-3 rounded-xl transition-colors"
            >
              🤖 المساعد الذكي
            </Link>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
