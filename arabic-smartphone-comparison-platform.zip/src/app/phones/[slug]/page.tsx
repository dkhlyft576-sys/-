import { db } from "@/db";
import { phones, companies } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { notFound } from "next/navigation";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import PhoneCard from "@/components/PhoneCard";
import RatingBar from "@/components/RatingBar";
import Link from "next/link";
import type { Metadata } from "next";

interface PhonePageProps {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: PhonePageProps): Promise<Metadata> {
  const { slug } = await params;
  const phone = await db.select().from(phones).where(eq(phones.slug, slug)).limit(1);
  if (!phone.length) return { title: "هاتف غير موجود | مقارن" };
  return {
    title: `${phone[0].nameAr} | مقارن`,
    description: phone[0].descriptionAr || `مواصفات وتقييم ${phone[0].nameAr}`,
  };
}

function getScoreLabel(score: number): string {
  if (score >= 90) return "ممتاز";
  if (score >= 80) return "جيد جداً";
  if (score >= 70) return "جيد";
  return "مقبول";
}

function getScoreColor(score: number): string {
  if (score >= 90) return "text-green-600 bg-green-50 border-green-200";
  if (score >= 80) return "text-lime-600 bg-lime-50 border-lime-200";
  if (score >= 70) return "text-yellow-600 bg-yellow-50 border-yellow-200";
  return "text-red-600 bg-red-50 border-red-200";
}

export default async function PhonePage({ params }: PhonePageProps) {
  const { slug } = await params;

  const phoneResult = await db
    .select({
      phone: phones,
      companyNameAr: companies.nameAr,
    })
    .from(phones)
    .leftJoin(companies, eq(phones.companyId, companies.id))
    .where(eq(phones.slug, slug))
    .limit(1);

  if (!phoneResult.length) notFound();
  const { phone, companyNameAr } = phoneResult[0];

  // Get competitors
  const competitors = phone.category
    ? await db
        .select()
        .from(phones)
        .where(eq(phones.category, phone.category))
        .limit(4)
    : [];

  const filteredCompetitors = competitors.filter((c) => c.id !== phone.id);
  const companyMap = Object.fromEntries(
    (await db.select().from(companies)).map((c) => [c.id, c])
  );

  return (
    <>
      <Navbar />
      <main className="flex-1">
        {/* Hero */}
        <section className="bg-gradient-to-br from-primary-50 via-white to-purple-50 border-b border-gray-100">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
            <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
              <Link href="/" className="hover:text-primary-600">الرئيسية</Link>
              <span>/</span>
              <span className="text-gray-900">{phone.nameAr}</span>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Phone Image */}
              <div className="bg-gradient-to-br from-gray-50 to-white rounded-3xl border border-gray-100 flex items-center justify-center h-72 sm:h-96">
                <span className="text-8xl sm:text-9xl">📱</span>
              </div>

              {/* Phone Info */}
              <div>
                {companyNameAr && (
                  <span className="text-sm text-primary-500 font-medium">{companyNameAr}</span>
                )}
                <h1 className="text-2xl sm:text-4xl font-extrabold text-gray-900 mt-1 mb-4">{phone.nameAr}</h1>
                
                {phone.descriptionAr && (
                  <p className="text-gray-600 leading-relaxed mb-6">{phone.descriptionAr}</p>
                )}

                {/* Price */}
                {phone.priceUsd && (
                  <div className="flex items-baseline gap-4 mb-6">
                    <span className="text-3xl font-extrabold text-gray-900">${phone.priceUsd}</span>
                    {phone.priceSar && (
                      <span className="text-lg text-gray-400">~{phone.priceSar} ر.س</span>
                    )}
                    {phone.priceAed && (
                      <span className="text-lg text-gray-400">~{phone.priceAed} د.إ</span>
                    )}
                  </div>
                )}

                {/* Overall Score */}
                {phone.overallScore && (
                  <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-2xl border-2 mb-6 ${getScoreColor(phone.overallScore)}`}>
                    <span className="text-2xl font-extrabold">{phone.overallScore}</span>
                    <span className="text-sm font-bold">{getScoreLabel(phone.overallScore)}/100</span>
                  </div>
                )}

                {/* Quick Specs */}
                <div className="grid grid-cols-2 gap-3 mb-6">
                  {phone.processor && (
                    <div className="bg-white rounded-xl border border-gray-100 p-3">
                      <span className="text-[10px] text-gray-400">المعالج</span>
                      <p className="text-sm font-semibold text-gray-900">{phone.processor}</p>
                    </div>
                  )}
                  {phone.ram && (
                    <div className="bg-white rounded-xl border border-gray-100 p-3">
                      <span className="text-[10px] text-gray-400">الرام</span>
                      <p className="text-sm font-semibold text-gray-900">{phone.ram}</p>
                    </div>
                  )}
                  {phone.batteryCapacity && (
                    <div className="bg-white rounded-xl border border-gray-100 p-3">
                      <span className="text-[10px] text-gray-400">البطارية</span>
                      <p className="text-sm font-semibold text-gray-900">{phone.batteryCapacity}</p>
                    </div>
                  )}
                  {phone.mainCamera && (
                    <div className="bg-white rounded-xl border border-gray-100 p-3">
                      <span className="text-[10px] text-gray-400">الكاميرا</span>
                      <p className="text-sm font-semibold text-gray-900">{phone.mainCamera.split("+")[0].trim()}</p>
                    </div>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="flex flex-wrap gap-3">
                  <Link
                    href={`/compare?phones=${phone.id}`}
                    className="inline-flex items-center gap-2 bg-primary-600 hover:bg-primary-700 text-white font-bold px-6 py-3 rounded-xl transition-colors"
                  >
                    ⚖️ مقارنة مع هاتف آخر
                  </Link>
                  <Link
                    href="/ai-assistant"
                    className="inline-flex items-center gap-2 bg-white border border-gray-200 hover:border-primary-300 text-gray-700 font-medium px-6 py-3 rounded-xl transition-colors"
                  >
                    🤖 اسأل المساعد الذكي
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Ratings */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
          <h2 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">⭐ التقييمات</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="bg-white rounded-2xl border border-gray-100 p-6">
              <RatingBar label="الأداء العام" score={phone.overallScore} />
              <RatingBar label="الأداء والسرعة" score={phone.performanceScore} />
              <RatingBar label="الكاميرا" score={phone.cameraScore} />
              <RatingBar label="البطارية" score={phone.batteryScore} />
              <RatingBar label="الشاشة" score={phone.displayScore} />
              <RatingBar label="القيمة مقابل السعر" score={phone.valueScore} />
            </div>

            {/* Pros & Cons */}
            <div className="space-y-4">
              {phone.prosAr && (phone.prosAr as string[]).length > 0 && (
                <div className="bg-green-50 rounded-2xl border border-green-100 p-6">
                  <h3 className="font-bold text-green-800 mb-3 flex items-center gap-2">
                    <span className="text-lg">✅</span> الإيجابيات
                  </h3>
                  <ul className="space-y-2">
                    {(phone.prosAr as string[]).map((pro, i) => (
                      <li key={i} className="text-sm text-green-700 flex items-start gap-2">
                        <span className="text-green-400 mt-0.5">•</span>
                        {pro}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              {phone.consAr && (phone.consAr as string[]).length > 0 && (
                <div className="bg-red-50 rounded-2xl border border-red-100 p-6">
                  <h3 className="font-bold text-red-800 mb-3 flex items-center gap-2">
                    <span className="text-lg">❌</span> السلبيات
                  </h3>
                  <ul className="space-y-2">
                    {(phone.consAr as string[]).map((con, i) => (
                      <li key={i} className="text-sm text-red-700 flex items-start gap-2">
                        <span className="text-red-400 mt-0.5">•</span>
                        {con}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            {/* Review */}
            {phone.reviewAr && (
              <div className="bg-white rounded-2xl border border-gray-100 p-6">
                <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                  <span className="text-lg">📝</span> المراجعة
                </h3>
                <p className="text-sm text-gray-600 leading-relaxed">{phone.reviewAr}</p>
              </div>
            )}
          </div>
        </section>

        {/* Full Specifications */}
        <section className="bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
            <h2 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">📋 المواصفات الكاملة</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-1 bg-gray-100 rounded-2xl overflow-hidden">
              {[
                { label: "المعالج", value: phone.processor },
                { label: "الرام", value: phone.ram },
                { label: "التخزين", value: phone.storage },
                { label: "حجم الشاشة", value: phone.displaySize },
                { label: "نوع الشاشة", value: phone.displayType },
                { label: "دقة الشاشة", value: phone.displayResolution },
                { label: "معدل التحديث", value: phone.refreshRate },
                { label: "سعة البطارية", value: phone.batteryCapacity },
                { label: "سرعة الشحن", value: phone.chargingSpeed },
                { label: "الكاميرا الخلفية", value: phone.mainCamera },
                { label: "الكاميرا الأمامية", value: phone.selfieCamera },
                { label: "نظام التشغيل", value: phone.os },
                { label: "الوزن", value: phone.weight },
                { label: "الأبعاد", value: phone.dimensions },
                { label: "NFC", value: phone.nfc ? "نعم" : "لا" },
                { label: "مقاومة الماء", value: phone.waterResistance },
                { label: "البصمة", value: phone.fingerprint },
                { label: "نوع الشريحة", value: phone.simType },
                { label: "5G", value: phone.fiveG ? "نعم" : "لا" },
                { label: "سنة الإصدار", value: phone.releaseYear?.toString() },
              ]
                .filter((s) => s.value)
                .map((spec, i) => (
                  <div key={i} className="bg-white px-4 py-3 flex items-center justify-between gap-2">
                    <span className="text-xs text-gray-500 shrink-0">{spec.label}</span>
                    <span className="text-xs font-semibold text-gray-900 text-left">{spec.value}</span>
                  </div>
                ))}
            </div>
          </div>
        </section>

        {/* Competitors */}
        {filteredCompetitors.length > 0 && (
          <section className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
            <h2 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">🔄 هواتف منافسة</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {filteredCompetitors.map((comp) => (
                <PhoneCard
                  key={comp.id}
                  phone={comp}
                  company={
                    companyMap[comp.companyId]
                      ? { nameAr: companyMap[comp.companyId].nameAr }
                      : undefined
                  }
                />
              ))}
            </div>
          </section>
        )}
      </main>
      <Footer />
    </>
  );
}
