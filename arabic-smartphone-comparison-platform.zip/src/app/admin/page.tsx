"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

interface Phone {
  id: number;
  nameAr: string;
  name: string;
  slug: string;
  priceUsd: string | null;
  overallScore: number | null;
  category: string | null;
  companyNameAr: string | null;
  createdAt: string;
}

interface Stats {
  phones: number;
  companies: number;
  articles: number;
  avgScores: {
    avgOverall: number;
    avgPerformance: number;
    avgCamera: number;
    avgBattery: number;
  } | null;
  categoryCounts: { category: string | null; count: number }[];
}

export default function AdminPage() {
  const [phones, setPhones] = useState<Phone[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<"overview" | "phones" | "add">("overview");

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [statsRes, phonesRes] = await Promise.all([
        fetch("/api/admin/phones?action=stats"),
        fetch("/api/admin/phones"),
      ]);
      const statsData = await statsRes.json();
      const phonesData = await phonesRes.json();
      setStats(statsData.stats || null);
      setPhones(phonesData.phones || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const deletePhone = async (id: number) => {
    if (!confirm("هل أنت متأكد من حذف هذا الهاتف؟")) return;
    try {
      await fetch(`/api/admin/phones?id=${id}`, { method: "DELETE" });
      setPhones(phones.filter((p) => p.id !== id));
    } catch (err) {
      console.error(err);
    }
  };

  const getCategoryLabel = (cat: string | null) => {
    const map: Record<string, string> = {
      flagship: "رائد",
      midrange: "متوسط",
      budget: "اقتصادي",
      gaming: "ألعاب",
      camera: "تصوير",
      battery: "بطارية",
    };
    return cat ? map[cat] || cat : "—";
  };

  return (
    <>
      <Navbar />
      <main className="flex-1 bg-gray-50">
        <div className="bg-gradient-to-br from-gray-800 to-gray-900 text-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
            <h1 className="text-2xl font-extrabold flex items-center gap-2">
              ⚙️ لوحة الإدارة
            </h1>
            <p className="text-gray-400 text-sm mt-1">إدارة الهواتف والمحتوى والإعدادات</p>
          </div>
        </div>

        {/* Tabs */}
        <div className="bg-white border-b border-gray-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <div className="flex gap-1">
              {[
                { key: "overview", label: "نظرة عامة" },
                { key: "phones", label: "الهواتف" },
                { key: "add", label: "إضافة هاتف" },
              ].map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key as any)}
                  className={`text-sm font-medium px-4 py-3 border-b-2 transition-colors ${
                    activeTab === tab.key
                      ? "border-primary-600 text-primary-600"
                      : "border-transparent text-gray-500 hover:text-gray-700"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
          {loading ? (
            <div className="text-center py-12">
              <div className="w-8 h-8 border-2 border-primary-400 border-t-transparent rounded-full animate-spin mx-auto" />
            </div>
          ) : (
            <>
              {/* Overview Tab */}
              {activeTab === "overview" && stats && (
                <div>
                  {/* Stats Cards */}
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                    <div className="bg-white rounded-xl border border-gray-100 p-5">
                      <span className="text-3xl font-extrabold text-primary-600">{stats.phones}</span>
                      <p className="text-sm text-gray-500 mt-1">هاتف</p>
                    </div>
                    <div className="bg-white rounded-xl border border-gray-100 p-5">
                      <span className="text-3xl font-extrabold text-primary-600">{stats.companies}</span>
                      <p className="text-sm text-gray-500 mt-1">شركة</p>
                    </div>
                    <div className="bg-white rounded-xl border border-gray-100 p-5">
                      <span className="text-3xl font-extrabold text-primary-600">{stats.articles}</span>
                      <p className="text-sm text-gray-500 mt-1">مقال</p>
                    </div>
                    <div className="bg-white rounded-xl border border-gray-100 p-5">
                      <span className="text-3xl font-extrabold text-primary-600">
                        {stats.avgScores?.avgOverall || "—"}
                      </span>
                      <p className="text-sm text-gray-500 mt-1">متوسط التقييم</p>
                    </div>
                  </div>

                  {/* Category Distribution */}
                  <div className="bg-white rounded-xl border border-gray-100 p-6">
                    <h3 className="font-bold text-gray-900 mb-4">توزيع الهواتف حسب الفئة</h3>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                      {stats.categoryCounts.map((cc) => (
                        <div key={cc.category || "none"} className="bg-gray-50 rounded-lg p-3 flex items-center justify-between">
                          <span className="text-sm text-gray-600">{getCategoryLabel(cc.category)}</span>
                          <span className="text-sm font-bold text-gray-900">{cc.count}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Average Scores */}
                  {stats.avgScores && (
                    <div className="bg-white rounded-xl border border-gray-100 p-6 mt-4">
                      <h3 className="font-bold text-gray-900 mb-4">متوسط التقييمات</h3>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                        <div className="text-center p-3 bg-blue-50 rounded-lg">
                          <span className="text-2xl font-extrabold text-blue-600">{stats.avgScores.avgPerformance}</span>
                          <p className="text-xs text-gray-500 mt-1">الأداء</p>
                        </div>
                        <div className="text-center p-3 bg-amber-50 rounded-lg">
                          <span className="text-2xl font-extrabold text-amber-600">{stats.avgScores.avgCamera}</span>
                          <p className="text-xs text-gray-500 mt-1">الكاميرا</p>
                        </div>
                        <div className="text-center p-3 bg-green-50 rounded-lg">
                          <span className="text-2xl font-extrabold text-green-600">{stats.avgScores.avgBattery}</span>
                          <p className="text-xs text-gray-500 mt-1">البطارية</p>
                        </div>
                        <div className="text-center p-3 bg-purple-50 rounded-lg">
                          <span className="text-2xl font-extrabold text-purple-600">{stats.avgScores.avgOverall}</span>
                          <p className="text-xs text-gray-500 mt-1">العام</p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Phones Tab */}
              {activeTab === "phones" && (
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-lg font-bold text-gray-900">قائمة الهواتف ({phones.length})</h2>
                    <button
                      onClick={() => setActiveTab("add")}
                      className="text-sm bg-primary-600 hover:bg-primary-700 text-white font-medium px-4 py-2 rounded-lg transition-colors"
                    >
                      + إضافة هاتف
                    </button>
                  </div>
                  <div className="bg-white rounded-xl border border-gray-100 overflow-hidden">
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="bg-gray-50 border-b border-gray-100">
                            <th className="px-4 py-3 text-xs font-medium text-gray-500 text-right">الهاتف</th>
                            <th className="px-4 py-3 text-xs font-medium text-gray-500 text-right">الشركة</th>
                            <th className="px-4 py-3 text-xs font-medium text-gray-500 text-right">الفئة</th>
                            <th className="px-4 py-3 text-xs font-medium text-gray-500 text-right">السعر</th>
                            <th className="px-4 py-3 text-xs font-medium text-gray-500 text-right">التقييم</th>
                            <th className="px-4 py-3 text-xs font-medium text-gray-500 text-right">إجراءات</th>
                          </tr>
                        </thead>
                        <tbody>
                          {phones.map((phone) => (
                            <tr key={phone.id} className="border-b border-gray-50 hover:bg-gray-50/50">
                              <td className="px-4 py-3">
                                <Link href={`/phones/${phone.slug}`} className="text-sm font-semibold text-gray-900 hover:text-primary-600">
                                  {phone.nameAr}
                                </Link>
                              </td>
                              <td className="px-4 py-3 text-sm text-gray-600">{phone.companyNameAr || "—"}</td>
                              <td className="px-4 py-3">
                                <span className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-full">
                                  {getCategoryLabel(phone.category)}
                                </span>
                              </td>
                              <td className="px-4 py-3 text-sm font-semibold text-gray-900">
                                {phone.priceUsd ? `$${phone.priceUsd}` : "—"}
                              </td>
                              <td className="px-4 py-3 text-sm font-bold">
                                <span className={phone.overallScore && phone.overallScore >= 90 ? "text-green-600" : phone.overallScore && phone.overallScore >= 80 ? "text-lime-600" : "text-yellow-600"}>
                                  {phone.overallScore || "—"}
                                </span>
                              </td>
                              <td className="px-4 py-3">
                                <div className="flex items-center gap-2">
                                  <Link
                                    href={`/phones/${phone.slug}`}
                                    className="text-xs text-primary-600 hover:text-primary-700 font-medium"
                                  >
                                    عرض
                                  </Link>
                                  <button
                                    onClick={() => deletePhone(phone.id)}
                                    className="text-xs text-red-500 hover:text-red-700 font-medium"
                                  >
                                    حذف
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* Add Phone Tab */}
              {activeTab === "add" && (
                <div className="bg-white rounded-xl border border-gray-100 p-6">
                  <h2 className="text-lg font-bold text-gray-900 mb-6">إضافة هاتف جديد</h2>
                  <p className="text-sm text-gray-500 mb-4">
                    لإضافة هاتف جديد، يمكنك استخدم سكريبت البذر أو إضافة بيانات الهاتف مباشرة إلى قاعدة البيانات.
                  </p>
                  <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm text-amber-800">
                    <p className="font-bold mb-1">💡 ملاحظة</p>
                    <p>نظام إضافة الهواتف عبر واجهة الويب قيد التطوير. حالياً يمكنك إضافة الهواتف عبر سكريبت البذر (seed) أو مباشرة من قاعدة البيانات.</p>
                  </div>
                  <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="bg-gray-50 rounded-lg p-4">
                      <h3 className="text-sm font-bold text-gray-900 mb-2">البيانات المطلوبة</h3>
                      <ul className="text-xs text-gray-600 space-y-1">
                        <li>• اسم الهاتف (عربي وإنجليزي)</li>
                        <li>• الشركة المصنعة</li>
                        <li>• المواصفات التقنية</li>
                        <li>• التقييمات (أداء، كاميرا، بطارية...)</li>
                        <li>• الأسعار (دولار، ريال، درهم)</li>
                        <li>• الإيجابيات والسلبيات</li>
                      </ul>
                    </div>
                    <div className="bg-gray-50 rounded-lg p-4">
                      <h3 className="text-sm font-bold text-gray-900 mb-2">الخطوات التالية</h3>
                      <ul className="text-xs text-gray-600 space-y-1">
                        <li>1. إنشاء نموذج إضافة هاتف</li>
                        <li>2. إضافة API لإدارة الهواتف</li>
                        <li>3. إضافة نظام رفع الصور</li>
                        <li>4. إضافة نظام المصادقة</li>
                        <li>5. إضافة نظام الإشعارات</li>
                      </ul>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </main>
      <Footer />
    </>
  );
}
