import { db } from "@/db";
import { phones, companies, articles } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import PhoneCard from "@/components/PhoneCard";
import Link from "next/link";

export const revalidate = 60;

async function getHomeData() {
  // Latest phones
  const latestPhones = await db
    .select({
      id: phones.id,
      nameAr: phones.nameAr,
      slug: phones.slug,
      image: phones.image,
      priceUsd: phones.priceUsd,
      priceSar: phones.priceSar,
      overallScore: phones.overallScore,
      performanceScore: phones.performanceScore,
      cameraScore: phones.cameraScore,
      batteryScore: phones.batteryScore,
      displayScore: phones.displayScore,
      valueScore: phones.valueScore,
      processor: phones.processor,
      mainCamera: phones.mainCamera,
      batteryCapacity: phones.batteryCapacity,
      category: phones.category,
      companyId: phones.companyId,
    })
    .from(phones)
    .orderBy(desc(phones.releaseYear), desc(phones.id))
    .limit(8);

  const companyIds = [...new Set(latestPhones.map((p) => p.companyId))];
  const companiesData = await db
    .select()
    .from(companies)
    .where(sql`${companies.id} IN (${sql.join(companyIds.map((id) => sql`${id}`), sql`, `)})`);
  const companyMap = Object.fromEntries(companiesData.map((c) => [c.id, c]));

  // Best by category
  const bestGaming = await db.select().from(phones).where(eq(phones.category, "gaming")).orderBy(desc(phones.performanceScore)).limit(4);
  const bestCamera = await db.select().from(phones).where(eq(phones.category, "camera")).orderBy(desc(phones.cameraScore)).limit(4);
  const bestBudget = await db.select().from(phones).where(eq(phones.category, "budget")).orderBy(desc(phones.valueScore)).limit(4);
  const bestBattery = await db.select().from(phones).where(eq(phones.category, "battery")).orderBy(desc(phones.batteryScore)).limit(4);

  // Articles
  const latestArticles = await db.select().from(articles).where(eq(articles.published, true)).orderBy(desc(articles.createdAt)).limit(4);

  return {
    latestPhones,
    companyMap,
    bestGaming,
    bestCamera,
    bestBudget,
    bestBattery,
    latestArticles,
  };
}

function CategorySection({
  title,
  icon,
  phones: categoryPhones,
  companyMap,
  link,
}: {
  title: string;
  icon: string;
  phones: typeof phones.$inferSelect[];
  companyMap: Record<number, any>;
  link: string;
}) {
  if (categoryPhones.length === 0) return null;
  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-bold text-gray-900 flex items-center gap-2">
          <span>{icon}</span>
          {title}
        </h2>
        <Link href={link} className="text-sm text-primary-600 hover:text-primary-700 font-medium">
          عرض الكل ←
        </Link>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {categoryPhones.map((phone) => (
          <PhoneCard
            key={phone.id}
            phone={phone}
            company={companyMap[phone.companyId] ? { nameAr: companyMap[phone.companyId].nameAr } : undefined}
          />
        ))}
      </div>
    </div>
  );
}

export default async function HomePage() {
  const data = await getHomeData();

  return (
    <>
      <Navbar />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative bg-gradient-to-br from-primary-600 via-primary-700 to-purple-800 text-white overflow-hidden">
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-10 right-20 w-72 h-72 bg-white rounded-full blur-3xl" />
            <div className="absolute bottom-10 left-20 w-96 h-96 bg-purple-300 rounded-full blur-3xl" />
          </div>
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 py-16 sm:py-24">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-3xl sm:text-5xl font-extrabold mb-4 leading-tight">
                اختر الهاتف المناسب
                <span className="block text-accent-400">في أقل من دقيقة</span>
              </h1>
              <p className="text-lg sm:text-xl text-primary-100 mb-8 leading-relaxed">
                منصة عربية ذكية لمقارنة الهواتف ومساعدتك على اتخاذ أفضل قرار شراء
                بمساعدة الذكاء الاصطناعي
              </p>

              {/* Search Box */}
              <form action="/search" method="get" className="max-w-2xl mx-auto">
                <div className="relative">
                  <input
                    type="text"
                    name="q"
                    placeholder="ابحث عن هاتف... مثال: أفضل هاتف للألعاب بسعر 400 دولار"
                    className="w-full h-14 sm:h-16 pr-6 pl-14 text-base sm:text-lg text-gray-900 rounded-2xl border-0 shadow-2xl focus:outline-none focus:ring-4 focus:ring-primary-300/50 placeholder:text-gray-400"
                  />
                  <button
                    type="submit"
                    className="absolute left-2 top-1/2 -translate-y-1/2 w-10 h-10 sm:w-12 sm:h-12 bg-primary-600 hover:bg-primary-700 text-white rounded-xl flex items-center justify-center transition-colors"
                  >
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                      <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
                    </svg>
                  </button>
                </div>
              </form>

              {/* Quick Actions */}
              <div className="flex flex-wrap justify-center gap-3 mt-6">
                <Link href="/ai-assistant" className="inline-flex items-center gap-1.5 bg-white/15 hover:bg-white/25 text-white text-sm font-medium px-4 py-2 rounded-full transition-colors backdrop-blur-sm">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M12 2a8 8 0 0 0-8 8c0 3.4 2.1 6.3 5 7.5V20h6v-2.5c2.9-1.2 5-4.1 5-7.5a8 8 0 0 0-8-8z"/>
                    <line x1="9" y1="23" x2="15" y2="23"/>
                  </svg>
                  المساعد الذكي
                </Link>
                <Link href="/compare" className="inline-flex items-center gap-1.5 bg-white/15 hover:bg-white/25 text-white text-sm font-medium px-4 py-2 rounded-full transition-colors backdrop-blur-sm">
                  ⚖️ مقارنة الهواتف
                </Link>
                <Link href="/best/flagship" className="inline-flex items-center gap-1.5 bg-white/15 hover:bg-white/25 text-white text-sm font-medium px-4 py-2 rounded-full transition-colors backdrop-blur-sm">
                  🏆 أفضل الهواتف
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Stats Bar */}
        <section className="bg-white border-b border-gray-100">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
              <div>
                <span className="text-2xl font-extrabold text-primary-600">{data.latestPhones.length + data.bestGaming.length + data.bestCamera.length}+</span>
                <p className="text-xs text-gray-500 mt-0.5">هاتف في قاعدة البيانات</p>
              </div>
              <div>
                <span className="text-2xl font-extrabold text-primary-600">4</span>
                <p className="text-xs text-gray-500 mt-0.5">فئات مقارنة</p>
              </div>
              <div>
                <span className="text-2xl font-extrabold text-primary-600">AI</span>
                <p className="text-xs text-gray-500 mt-0.5">مساعد ذكي</p>
              </div>
              <div>
                <span className="text-2xl font-extrabold text-primary-600">100%</span>
                <p className="text-xs text-gray-500 mt-0.5">محتوى عربي</p>
              </div>
            </div>
          </div>
        </section>

        {/* Latest Phones */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
              📱 أحدث الهواتف
            </h2>
            <Link href="/search" className="text-sm text-primary-600 hover:text-primary-700 font-medium">
              عرض الكل ←
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {data.latestPhones.map((phone) => (
              <PhoneCard
                key={phone.id}
                phone={phone}
                company={
                  data.companyMap[phone.companyId]
                    ? { nameAr: data.companyMap[phone.companyId].nameAr }
                    : undefined
                }
              />
            ))}
          </div>
        </section>

        {/* Best by Category */}
        <section className="bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12 space-y-12">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">🏆 أفضل الهواتف حسب الفئة</h2>
              <p className="text-gray-500">اختر الفئة المناسبة لاحتياجاتك</p>
            </div>

            <CategorySection title="أفضل هواتف الألعاب" icon="🎮" phones={data.bestGaming} companyMap={data.companyMap} link="/best/gaming" />
            <CategorySection title="أفضل هواتف التصوير" icon="📷" phones={data.bestCamera} companyMap={data.companyMap} link="/best/camera" />
            <CategorySection title="أفضل الهواتف الاقتصادية" icon="💰" phones={data.bestBudget} companyMap={data.companyMap} link="/best/budget" />
            <CategorySection title="أفضل بطارية" icon="🔋" phones={data.bestBattery} companyMap={data.companyMap} link="/best/battery" />
          </div>
        </section>

        {/* Budget Categories */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-2">💵 أفضل الهواتف حسب الميزانية</h2>
            <p className="text-gray-500">اختر الميزانية المناسبة لك</p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              { label: "أقل من 200$", sub: "اقتصادي", link: "/best/budget-200", color: "from-green-400 to-emerald-500" },
              { label: "أقل من 300$", sub: "متوسط-اقتصادي", link: "/best/budget-300", color: "from-blue-400 to-cyan-500" },
              { label: "أقل من 500$", sub: "متوسط-رائد", link: "/best/budget-500", color: "from-purple-400 to-violet-500" },
              { label: "أقل من 700$", sub: "شبه رائد", link: "/best/budget-700", color: "from-amber-400 to-orange-500" },
            ].map((item) => (
              <Link key={item.link} href={item.link} className="group">
                <div className="card-hover bg-white rounded-2xl border border-gray-100 p-6 text-center overflow-hidden relative">
                  <div className={`absolute top-0 left-0 right-0 h-1 bg-gradient-to-l ${item.color}`} />
                  <h3 className="text-lg font-bold text-gray-900 group-hover:text-primary-600 transition-colors">{item.label}</h3>
                  <p className="text-xs text-gray-400 mt-1">{item.sub}</p>
                  <span className="text-primary-500 text-sm font-medium mt-3 block">تصفح ←</span>
                </div>
              </Link>
            ))}
          </div>
        </section>

        {/* AI Assistant CTA */}
        <section className="bg-gradient-to-br from-primary-50 via-purple-50 to-pink-50">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 py-16 text-center">
            <div className="w-20 h-20 bg-gradient-to-br from-primary-500 to-purple-600 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-lg shadow-primary-200">
              <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 2a8 8 0 0 0-8 8c0 3.4 2.1 6.3 5 7.5V20h6v-2.5c2.9-1.2 5-4.1 5-7.5a8 8 0 0 0-8-8z"/>
                <line x1="9" y1="23" x2="15" y2="23"/>
              </svg>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-4">
              لست متأكداً أي هاتف تختار؟
            </h2>
            <p className="text-gray-600 mb-8 text-lg">
              المساعد الذكي يساعدك في العثور على الهاتف المثالي بناءً على احتياجاتك وميزانيتك
            </p>
            <Link
              href="/ai-assistant"
              className="inline-flex items-center gap-2 bg-primary-600 hover:bg-primary-700 text-white font-bold px-8 py-4 rounded-2xl text-lg transition-colors shadow-lg shadow-primary-200"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 2a8 8 0 0 0-8 8c0 3.4 2.1 6.3 5 7.5V20h6v-2.5c2.9-1.2 5-4.1 5-7.5a8 8 0 0 0-8-8z"/>
                <line x1="9" y1="23" x2="15" y2="23"/>
              </svg>
              جرّب المساعد الذكي الآن
            </Link>
          </div>
        </section>

        {/* Articles */}
        {data.latestArticles.length > 0 && (
          <section className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
              📝 مقالات ونصائح
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {data.latestArticles.map((article) => (
                <Link key={article.id} href="#" className="group">
                  <div className="card-hover bg-white rounded-2xl border border-gray-100 p-6">
                    <span className="text-[10px] font-bold text-primary-500 bg-primary-50 px-2 py-1 rounded-full">
                      {article.category === "comparison" ? "مقارنة" :
                       article.category === "guide" ? "دليل" :
                       article.category === "gaming" ? "ألعاب" :
                       article.category === "tips" ? "نصائح" : article.category}
                    </span>
                    <h3 className="text-base font-bold text-gray-900 mt-3 mb-2 group-hover:text-primary-600 transition-colors line-clamp-2">
                      {article.titleAr}
                    </h3>
                    <p className="text-sm text-gray-500 line-clamp-2">{article.contentAr.substring(0, 120)}...</p>
                  </div>
                </Link>
              ))}
            </div>
          </section>
        )}
      </main>
      <Footer />
    </>
  );
}
