import { db } from "@/db";
import { phones, companies } from "@/db/schema";
import { like, or, and, desc, sql, eq } from "drizzle-orm";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import PhoneCard from "@/components/PhoneCard";
import Link from "next/link";
import type { Metadata } from "next";

interface SearchPageProps {
  searchParams: Promise<{ q?: string; category?: string; maxPrice?: string }>;
}

export async function generateMetadata({ searchParams }: SearchPageProps): Promise<Metadata> {
  const { q } = await searchParams;
  return {
    title: q ? `نتائج البحث: ${q} | مقارن` : "البحث عن هاتف | مقارن",
  };
}

export default async function SearchPage({ searchParams }: SearchPageProps) {
  const { q, category, maxPrice } = await searchParams;

  let results: any[] = [];

  if (q || category || maxPrice) {
    const conditions: any[] = [];

    if (q) {
      conditions.push(
        or(
          like(phones.nameAr, `%${q}%`),
          like(phones.name, `%${q}%`),
          like(phones.slug, `%${q}%`),
          like(companies.nameAr, `%${q}%`),
          like(companies.name, `%${q}%`),
          like(phones.processor, `%${q}%`)
        )!
      );
    }

    if (category) {
      conditions.push(eq(phones.category, category));
    }

    if (maxPrice) {
      conditions.push(sql`${phones.priceUsd}::numeric <= ${maxPrice}::numeric`);
    }

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

    results = await db
      .select({
        id: phones.id,
        nameAr: phones.nameAr,
        slug: phones.slug,
        image: phones.image,
        priceUsd: phones.priceUsd,
        priceSar: phones.priceSar,
        overallScore: phones.overallScore,
        performanceScore: phones.performanceScore,
        cameraScore: phones.cameraScore,
        batteryScore: phones.batteryScore,
        displayScore: phones.displayScore,
        valueScore: phones.valueScore,
        processor: phones.processor,
        mainCamera: phones.mainCamera,
        batteryCapacity: phones.batteryCapacity,
        category: phones.category,
        companyId: phones.companyId,
        companyNameAr: companies.nameAr,
      })
      .from(phones)
      .leftJoin(companies, eq(phones.companyId, companies.id))
      .where(whereClause)
      .orderBy(desc(phones.overallScore))
      .limit(50);
  }

  const companyMap: Record<number, { nameAr: string }> = {};
  results.forEach((r) => {
    if (r.companyId && r.companyNameAr) {
      companyMap[r.companyId] = { nameAr: r.companyNameAr };
    }
  });

  const categories = [
    { value: "", label: "الكل" },
    { value: "flagship", label: "رائد" },
    { value: "gaming", label: "ألعاب" },
    { value: "camera", label: "تصوير" },
    { value: "battery", label: "بطارية" },
    { value: "midrange", label: "متوسط" },
    { value: "budget", label: "اقتصادي" },
  ];

  return (
    <>
      <Navbar />
      <main className="flex-1">
        <div className="bg-gradient-to-br from-primary-50 via-white to-purple-50 border-b border-gray-100">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900 mb-4">🔍 البحث عن هاتف</h1>
            
            {/* Search Form */}
            <form action="/search" method="get" className="mb-4">
              <div className="flex gap-2">
                <input
                  type="text"
                  name="q"
                  defaultValue={q || ""}
                  placeholder="ابحث بالاسم أو الشركة أو المعالج..."
                  className="flex-1 h-12 px-4 text-base rounded-xl border border-gray-200 bg-white focus:border-primary-400 focus:outline-none focus:ring-2 focus:ring-primary-100"
                />
                <button
                  type="submit"
                  className="h-12 px-6 bg-primary-600 hover:bg-primary-700 text-white font-medium rounded-xl transition-colors"
                >
                  بحث
                </button>
              </div>
            </form>

            {/* Filters */}
            <div className="flex flex-wrap gap-2">
              {categories.map((cat) => (
                <Link
                  key={cat.value}
                  href={`/search?${cat.value ? `category=${cat.value}` : ""}${q ? `&q=${q}` : ""}`}
                  className={`text-xs font-medium px-3 py-1.5 rounded-full transition-colors ${
                    (category || "") === cat.value
                      ? "bg-primary-100 text-primary-700"
                      : "bg-white border border-gray-200 text-gray-600 hover:border-primary-300"
                  }`}
                >
                  {cat.label}
                </Link>
              ))}
              {["200", "300", "500", "700", "1000"].map((price) => (
                <Link
                  key={price}
                  href={`/search?maxPrice=${price}${q ? `&q=${q}` : ""}${category ? `&category=${category}` : ""}`}
                  className={`text-xs font-medium px-3 py-1.5 rounded-full transition-colors ${
                    maxPrice === price
                      ? "bg-primary-100 text-primary-700"
                      : "bg-white border border-gray-200 text-gray-600 hover:border-primary-300"
                  }`}
                >
                  أقل من ${price}
                </Link>
              ))}
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
          {q && (
            <p className="text-sm text-gray-500 mb-4">
              نتائج البحث عن &quot;{q}&quot;: {results.length} هاتف
            </p>
          )}

          {results.length === 0 && (q || category || maxPrice) ? (
            <div className="text-center py-16">
              <span className="text-5xl mb-4 block">🔍</span>
              <h3 className="text-lg font-bold text-gray-900 mb-2">لم يتم العثور على نتائج</h3>
              <p className="text-sm text-gray-500">جرب كلمات بحث مختلفة أو قلل الفلاتر</p>
              <Link href="/ai-assistant" className="inline-flex items-center gap-2 mt-4 text-primary-600 hover:text-primary-700 font-medium text-sm">
                🤖 أو اسأل المساعد الذكي
              </Link>
            </div>
          ) : results.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {results.map((phone) => (
                <PhoneCard
                  key={phone.id}
                  phone={phone}
                  company={
                    companyMap[phone.companyId]
                      ? companyMap[phone.companyId]
                      : undefined
                  }
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <span className="text-5xl mb-4 block">📱</span>
              <h3 className="text-lg font-bold text-gray-900 mb-2">ابدأ البحث عن هاتفك المثالي</h3>
              <p className="text-sm text-gray-500">اكتب اسم الهاتف أو الشركة أو استخدم الفلاتر</p>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </>
  );
}
