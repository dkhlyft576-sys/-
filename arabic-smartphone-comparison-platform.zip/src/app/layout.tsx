import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "مقارن - منصة مقارنة الهواتف الذكية | أفضل الهواتف والمقارنات",
  description:
    "منصة عربية ذكية لمقارنة الهواتف الذكية ومساعدتك على اختيار الهاتف المناسب. مقارنات شاملة، تقييمات مفصلة، ومساعد ذكاء اصطناعي.",
  keywords: [
    "مقارنة هواتف",
    "أفضل الهواتف",
    "تقييم الهواتف",
    "مواصفات الهواتف",
    "مساعد ذكاء اصطناعي",
  ],
  openGraph: {
    title: "مقارن - منصة مقارنة الهواتف الذكية",
    description:
      "منصة عربية ذكية لمقارنة الهواتف الذكية ومساعدتك على اختيار الهاتف المناسب",
    type: "website",
    locale: "ar_SA",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body className="bg-gray-50 text-gray-900 antialiased min-h-screen flex flex-col">
        {children}
      </body>
    </html>
  );
}
