import { db } from "@/db";
import { phones, companies } from "@/db/schema";
import { eq, and, lte, gte, desc, sql } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

// POST /api/ai-recommend - AI-powered phone recommendation
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { query } = body as { query: string };

    if (!query) {
      return NextResponse.json({ error: "يرجى كتابة طلبك" }, { status: 400 });
    }

    const normalizedQuery = query.trim().toLowerCase();

    // Parse the user query to determine criteria
    let conditions: any[] = [];
    let explanation = "";
    let sortBy: any = desc(phones.overallScore);

    // Budget detection
    const budgetMatch = normalizedQuery.match(
      /(\d+)\s*(دولار|دولارات|\$|usd)/
    );
    let maxBudget = 0;
    if (budgetMatch) {
      maxBudget = parseInt(budgetMatch[1]);
      conditions.push(lte(phones.priceUsd, String(maxBudget)));
      explanation += `بحثت عن هواتف بسعر أقل من ${maxBudget} دولار`;
    }

    // Gaming detection
    if (
      normalizedQuery.includes("لع") ||
      normalizedQuery.includes("جيم") ||
      normalizedQuery.includes("gaming") ||
      normalizedQuery.includes("ألعاب")
    ) {
      conditions.push(eq(phones.category, "gaming"));
      if (!explanation) explanation += "بحثت عن أفضل هواتف الألعاب";
      else explanation += " تناسب الألعاب";
      sortBy = desc(phones.performanceScore);
    }

    // Camera detection
    if (
      normalizedQuery.includes("صور") ||
      normalizedQuery.includes("كاميرا") ||
      normalizedQuery.includes("تصوير") ||
      normalizedQuery.includes("camera")
    ) {
      conditions.push(eq(phones.category, "camera"));
      if (!explanation) explanation += "بحثت عن أفضل هواتف التصوير";
      else explanation += " مع كاميرا ممتازة";
      sortBy = desc(phones.cameraScore);
    }

    // Battery detection
    if (
      normalizedQuery.includes("بطاري") ||
      normalizedQuery.includes("شحن") ||
      normalizedQuery.includes("تدوم") ||
      normalizedQuery.includes("battery")
    ) {
      if (!explanation) explanation += "بحثت عن هواتف بأفضل بطارية";
      else explanation += " وبطارية قوية";
      sortBy = desc(phones.batteryScore);
    }

    // Display/Screen detection
    if (
      normalizedQuery.includes("شاش") ||
      normalizedQuery.includes("display") ||
      normalizedQuery.includes("شاشة")
    ) {
      if (!explanation) explanation += "بحثت عن هواتف بأفضل شاشة";
      else explanation += " وشاشة ممتازة";
      sortBy = desc(phones.displayScore);
    }

    // Value detection
    if (
      normalizedQuery.includes("قيمة") ||
      normalizedQuery.includes("قيم") ||
      normalizedQuery.includes("مقابل السعر") ||
      normalizedQuery.includes("اقتصاد") ||
      normalizedQuery.includes("رخص")
    ) {
      if (!explanation) explanation += "بحثت عن أفضل قيمة مقابل السعر";
      else explanation += " وبأفضل قيمة مقابل السعر";
      sortBy = desc(phones.valueScore);
    }

    // Flagship detection
    if (
      normalizedQuery.includes("رائد") ||
      normalizedQuery.includes("flagship") ||
      normalizedQuery.includes("أفضل هاتف")
    ) {
      conditions.push(eq(phones.category, "flagship"));
      if (!explanation) explanation += "بحثت عن أفضل الهواتف الرائدة";
    }

    // Budget category detection
    if (
      normalizedQuery.includes("رخيص") ||
      normalizedQuery.includes("اقتصادي") ||
      normalizedQuery.includes("budget") ||
      normalizedQuery.includes("أرخص")
    ) {
      conditions.push(eq(phones.category, "budget"));
      if (!explanation) explanation += "بحثت عن أفضل الهواتف الاقتصادية";
    }

    if (!explanation) {
      explanation = "بحثت عن أفضل الهواتف المتاحة";
    }

    // Build query
    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

    const results = await db
      .select({
        id: phones.id,
        nameAr: phones.nameAr,
        slug: phones.slug,
        priceUsd: phones.priceUsd,
        priceSar: phones.priceSar,
        overallScore: phones.overallScore,
        performanceScore: phones.performanceScore,
        cameraScore: phones.cameraScore,
        batteryScore: phones.batteryScore,
        displayScore: phones.displayScore,
        valueScore: phones.valueScore,
        processor: phones.processor,
        mainCamera: phones.mainCamera,
        batteryCapacity: phones.batteryCapacity,
        category: phones.category,
        descriptionAr: phones.descriptionAr,
        companyNameAr: companies.nameAr,
      })
      .from(phones)
      .leftJoin(companies, eq(phones.companyId, companies.id))
      .where(whereClause)
      .orderBy(sortBy)
      .limit(5);

    // If no results with specific criteria, fallback to top rated
    let recommendations = results;
    if (results.length === 0) {
      recommendations = await db
        .select({
          id: phones.id,
          nameAr: phones.nameAr,
          slug: phones.slug,
          priceUsd: phones.priceUsd,
          priceSar: phones.priceSar,
          overallScore: phones.overallScore,
          performanceScore: phones.performanceScore,
          cameraScore: phones.cameraScore,
          batteryScore: phones.batteryScore,
          displayScore: phones.displayScore,
          valueScore: phones.valueScore,
          processor: phones.processor,
          mainCamera: phones.mainCamera,
          batteryCapacity: phones.batteryCapacity,
          category: phones.category,
          descriptionAr: phones.descriptionAr,
          companyNameAr: companies.nameAr,
        })
        .from(phones)
        .leftJoin(companies, eq(phones.companyId, companies.id))
        .orderBy(desc(phones.overallScore))
        .limit(5);

      explanation =
        "لم أجد هواتف تطابق معاييرك بالضبط، لكن هذه أفضل الهواتف المتاحة:";
    }

    // Format response
    let message = `🔍 ${explanation}\n\n`;
    
    if (recommendations.length === 0) {
      message = "عذراً، لم أجد هواتف تطابق بحثك. جرب استخدام كلمات مختلفة مثل 'أفضل هاتف للألعاب' أو 'هاتف بسعر 300 دولار'.";
    } else {
      recommendations.forEach((phone, i) => {
        message += `${i + 1}. 📱 **${phone.nameAr}**${phone.companyNameAr ? ` (${phone.companyNameAr})` : ""}\n`;
        if (phone.priceUsd) message += `   💰 السعر: $${phone.priceUsd}\n`;
        if (phone.overallScore) message += `   ⭐ التقييم: ${phone.overallScore}/100\n`;
        if (phone.performanceScore) message += `   ⚡ الأداء: ${phone.performanceScore}/100\n`;
        if (phone.cameraScore) message += `   📷 الكاميرا: ${phone.cameraScore}/100\n`;
        if (phone.batteryScore) message += `   🔋 البطارية: ${phone.batteryScore}/100\n`;
        if (phone.descriptionAr) message += `   📝 ${phone.descriptionAr}\n`;
        message += `\n`;
      });
    }

    return NextResponse.json({
      message,
      recommendations: recommendations.map((p) => ({
        ...p,
        url: `/phones/${p.slug}`,
      })),
    });
  } catch (error) {
    console.error("Error in AI recommendation:", error);
    return NextResponse.json(
      { error: "حدث خطأ في معالجة طلبك" },
      { status: 500 }
    );
  }
}
