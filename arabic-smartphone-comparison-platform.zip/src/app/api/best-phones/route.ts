import { db } from "@/db";
import { phones, companies } from "@/db/schema";
import { eq, lte, desc, sql } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

// GET /api/best-phones?category=gaming&maxPrice=500
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get("category");
    const maxPrice = searchParams.get("maxPrice");

    const conditions: any[] = [];

    if (category && category.startsWith("budget-")) {
      const price = category.replace("budget-", "");
      conditions.push(lte(phones.priceUsd, price));
    } else if (category) {
      conditions.push(eq(phones.category, category));
    }

    if (maxPrice) {
      conditions.push(lte(phones.priceUsd, maxPrice));
    }

    const whereClause = conditions.length > 0 ? sql`${sql.join(conditions.map(c => sql`(${c})`), sql` AND `)}` : undefined;

    // Determine sort order based on category
    let orderBy: any = desc(phones.overallScore);
    if (category === "gaming") orderBy = desc(phones.performanceScore);
    if (category === "camera") orderBy = desc(phones.cameraScore);
    if (category === "battery") orderBy = desc(phones.batteryScore);
    if (category === "budget" || category?.startsWith("budget-")) orderBy = desc(phones.valueScore);

    const results = await db
      .select({
        id: phones.id,
        nameAr: phones.nameAr,
        slug: phones.slug,
        image: phones.image,
        priceUsd: phones.priceUsd,
        priceSar: phones.priceSar,
        overallScore: phones.overallScore,
        performanceScore: phones.performanceScore,
        cameraScore: phones.cameraScore,
        batteryScore: phones.batteryScore,
        displayScore: phones.displayScore,
        valueScore: phones.valueScore,
        processor: phones.processor,
        mainCamera: phones.mainCamera,
        batteryCapacity: phones.batteryCapacity,
        category: phones.category,
        releaseYear: phones.releaseYear,
        companyNameAr: companies.nameAr,
      })
      .from(phones)
      .leftJoin(companies, eq(phones.companyId, companies.id))
      .where(whereClause)
      .orderBy(orderBy)
      .limit(20);

    return NextResponse.json({ phones: results, category });
  } catch (error) {
    console.error("Error fetching best phones:", error);
    return NextResponse.json({ error: "فشل في جلب الهواتف" }, { status: 500 });
  }
}
