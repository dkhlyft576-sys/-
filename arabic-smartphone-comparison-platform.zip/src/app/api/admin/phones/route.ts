import { db } from "@/db";
import { phones, companies, articles } from "@/db/schema";
import { eq, desc, sql } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

// GET /api/admin/stats - Dashboard statistics
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const action = searchParams.get("action");

    if (action === "stats") {
      const phoneCount = await db.select({ count: sql<number>`count(*)::int` }).from(phones);
      const companyCount = await db.select({ count: sql<number>`count(*)::int` }).from(companies);
      const articleCount = await db.select({ count: sql<number>`count(*)::int` }).from(articles);

      const avgScores = await db
        .select({
          avgOverall: sql<number>`round(avg(${phones.overallScore})::numeric, 1)`,
          avgPerformance: sql<number>`round(avg(${phones.performanceScore})::numeric, 1)`,
          avgCamera: sql<number>`round(avg(${phones.cameraScore})::numeric, 1)`,
          avgBattery: sql<number>`round(avg(${phones.batteryScore})::numeric, 1)`,
        })
        .from(phones);

      const categoryCounts = await db
        .select({
          category: phones.category,
          count: sql<number>`count(*)::int`,
        })
        .from(phones)
        .groupBy(phones.category);

      const recentPhones = await db
        .select({
          id: phones.id,
          nameAr: phones.nameAr,
          slug: phones.slug,
          priceUsd: phones.priceUsd,
          overallScore: phones.overallScore,
          category: phones.category,
          createdAt: phones.createdAt,
        })
        .from(phones)
        .orderBy(desc(phones.createdAt))
        .limit(5);

      return NextResponse.json({
        stats: {
          phones: phoneCount[0]?.count || 0,
          companies: companyCount[0]?.count || 0,
          articles: articleCount[0]?.count || 0,
          avgScores: avgScores[0],
          categoryCounts,
        },
        recentPhones,
      });
    }

    // Default: return all phones for admin
    const allPhones = await db
      .select({
        id: phones.id,
        nameAr: phones.nameAr,
        name: phones.name,
        slug: phones.slug,
        priceUsd: phones.priceUsd,
        overallScore: phones.overallScore,
        category: phones.category,
        companyNameAr: companies.nameAr,
        createdAt: phones.createdAt,
      })
      .from(phones)
      .leftJoin(companies, eq(phones.companyId, companies.id))
      .orderBy(desc(phones.id));

    return NextResponse.json({ phones: allPhones });
  } catch (error) {
    console.error("Error fetching admin data:", error);
    return NextResponse.json({ error: "فشل في جلب البيانات" }, { status: 500 });
  }
}

// DELETE /api/admin/phones?id=X
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ error: "معرف الهاتف مطلوب" }, { status: 400 });
    }

    await db.delete(phones).where(eq(phones.id, parseInt(id)));

    return NextResponse.json({ success: true, message: "تم حذف الهاتف بنجاح" });
  } catch (error) {
    console.error("Error deleting phone:", error);
    return NextResponse.json({ error: "فشل في حذف الهاتف" }, { status: 500 });
  }
}
