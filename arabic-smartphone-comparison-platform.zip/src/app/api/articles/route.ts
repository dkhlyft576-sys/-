import { db } from "@/db";
import { articles } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

// GET /api/articles
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const slug = searchParams.get("slug");
    const category = searchParams.get("category");
    const limit = parseInt(searchParams.get("limit") || "10");

    if (slug) {
      const article = await db
        .select()
        .from(articles)
        .where(eq(articles.slug, slug))
        .limit(1);

      if (!article.length) {
        return NextResponse.json({ error: "المقال غير موجود" }, { status: 404 });
      }
      return NextResponse.json({ article: article[0] });
    }

    const conditions: any[] = [];
    if (category) {
      conditions.push(eq(articles.category, category));
    }
    conditions.push(eq(articles.published, true));

    const result = await db
      .select()
      .from(articles)
      .where(conditions.length > 0 ? eq(articles.published, true) : undefined)
      .orderBy(desc(articles.createdAt))
      .limit(limit);

    return NextResponse.json({ articles: result });
  } catch (error) {
    console.error("Error fetching articles:", error);
    return NextResponse.json({ error: "فشل في جلب المقالات" }, { status: 500 });
  }
}
