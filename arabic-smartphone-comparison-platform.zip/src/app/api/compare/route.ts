import { db } from "@/db";
import { phones, companies } from "@/db/schema";
import { eq, desc, sql, and, lte } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

// POST /api/compare - Compare phones
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { phoneIds } = body as { phoneIds: number[] };

    if (!phoneIds || phoneIds.length < 2 || phoneIds.length > 4) {
      return NextResponse.json(
        { error: "يجب اختيار 2 إلى 4 هواتف للمقارنة" },
        { status: 400 }
      );
    }

    const results = await db
      .select({
        phone: phones,
        companyNameAr: companies.nameAr,
        companyName: companies.name,
      })
      .from(phones)
      .leftJoin(companies, eq(phones.companyId, companies.id))
      .where(sql`${phones.id} IN (${sql.join(phoneIds.map((id) => sql`${id}`), sql`, `)})`);

    const formatted = results.map((r) => ({
      ...r.phone,
      companyNameAr: r.companyNameAr,
      companyName: r.companyName,
    }));

    return NextResponse.json({ phones: formatted });
  } catch (error) {
    console.error("Error comparing phones:", error);
    return NextResponse.json({ error: "فشل في مقارنة الهواتف" }, { status: 500 });
  }
}

// GET /api/compare - Popular comparisons
export async function GET() {
  try {
    // Return some default popular comparisons
    const popularComparisons = [
      { label: "سامسونج S24 الترا vs آيفون 15 برو ماكس", phoneIds: [1, 2] },
      { label: "شاومي 14 الترا vs أوبو فايند X7 الترا", phoneIds: [3, 9] },
      { label: "ون بلس 12 vs ريالمي GT 5 برو", phoneIds: [4, 8] },
    ];

    // Fetch all phones needed
    const allIds = popularComparisons.flatMap((c) => c.phoneIds);
    const phoneResults = await db
      .select({
        id: phones.id,
        nameAr: phones.nameAr,
        slug: phones.slug,
        image: phones.image,
        priceUsd: phones.priceUsd,
        overallScore: phones.overallScore,
        companyNameAr: companies.nameAr,
      })
      .from(phones)
      .leftJoin(companies, eq(phones.companyId, companies.id))
      .where(sql`${phones.id} IN (${sql.join(allIds.map((id) => sql`${id}`), sql`, `)})`);

    const phoneMap = Object.fromEntries(phoneResults.map((p) => [p.id, p]));

    const result = popularComparisons.map((comp) => ({
      label: comp.label,
      phones: comp.phoneIds
        .map((id) => phoneMap[id])
        .filter(Boolean),
    }));

    return NextResponse.json({ comparisons: result });
  } catch (error) {
    console.error("Error fetching popular comparisons:", error);
    return NextResponse.json({ error: "فشل في جلب المقارنات" }, { status: 500 });
  }
}
