import { db } from "@/db";
import { phones, companies, comments, phoneImages } from "@/db/schema";
import { eq, desc, ne, and } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

// GET /api/phones/[id] - Get phone by slug or ID
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const isSlug = isNaN(Number(id));

    // Fetch phone with company
    const phoneQuery = db
      .select({
        phone: phones,
        companyNameAr: companies.nameAr,
        companyName: companies.name,
      })
      .from(phones)
      .leftJoin(companies, eq(phones.companyId, companies.id));

    const phoneResult = isSlug
      ? await phoneQuery.where(eq(phones.slug, id))
      : await phoneQuery.where(eq(phones.id, parseInt(id)));

    if (!phoneResult.length || !phoneResult[0].phone) {
      return NextResponse.json({ error: "الهاتف غير موجود" }, { status: 404 });
    }

    const phone = phoneResult[0].phone;
    const companyName = phoneResult[0].companyNameAr;

    // Fetch phone images
    const images = await db
      .select()
      .from(phoneImages)
      .where(eq(phoneImages.phoneId, phone.id))
      .orderBy(phoneImages.sortOrder);

    // Fetch comments
    const phoneComments = await db
      .select()
      .from(comments)
      .where(eq(comments.phoneId, phone.id))
      .orderBy(desc(comments.createdAt))
      .limit(20);

    // Fetch competing phones (same category, similar price)
    const competitors = phone.category
      ? await db
          .select({
            id: phones.id,
            nameAr: phones.nameAr,
            slug: phones.slug,
            image: phones.image,
            priceUsd: phones.priceUsd,
            overallScore: phones.overallScore,
            category: phones.category,
          })
          .from(phones)
          .where(
            and(
              eq(phones.category, phone.category),
              ne(phones.id, phone.id)
            )
          )
          .limit(4)
      : [];

    return NextResponse.json({
      phone: {
        ...phone,
        companyNameAr: companyName,
      },
      images,
      comments: phoneComments,
      competitors,
    });
  } catch (error) {
    console.error("Error fetching phone:", error);
    return NextResponse.json({ error: "فشل في جلب بيانات الهاتف" }, { status: 500 });
  }
}

// POST /api/phones/[id]/comments - Add comment
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const phoneId = parseInt(id);
    const body = await request.json();

    if (!body.authorName || !body.content) {
      return NextResponse.json(
        { error: "الاسم والمحتوى مطلوبان" },
        { status: 400 }
      );
    }

    const newComment = await db
      .insert(comments)
      .values({
        phoneId,
        authorName: body.authorName,
        content: body.content,
        rating: body.rating || null,
      })
      .returning();

    return NextResponse.json(newComment[0], { status: 201 });
  } catch (error) {
    console.error("Error adding comment:", error);
    return NextResponse.json({ error: "فشل في إضافة التعليق" }, { status: 500 });
  }
}
