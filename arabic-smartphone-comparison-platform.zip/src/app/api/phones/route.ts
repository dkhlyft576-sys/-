import { db } from "@/db";
import { phones, companies } from "@/db/schema";
import { desc, eq, like, or, and, gte, lte, sql } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

// GET /api/phones - List phones with filters
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get("search");
    const category = searchParams.get("category");
    const company = searchParams.get("company");
    const minPrice = searchParams.get("minPrice");
    const maxPrice = searchParams.get("maxPrice");
    const sortBy = searchParams.get("sortBy") || "newest";
    const limit = parseInt(searchParams.get("limit") || "20");
    const offset = parseInt(searchParams.get("offset") || "0");

    let query = db
      .select({
        id: phones.id,
        nameAr: phones.nameAr,
        slug: phones.slug,
        image: phones.image,
        priceUsd: phones.priceUsd,
        priceSar: phones.priceSar,
        overallScore: phones.overallScore,
        performanceScore: phones.performanceScore,
        cameraScore: phones.cameraScore,
        batteryScore: phones.batteryScore,
        displayScore: phones.displayScore,
        valueScore: phones.valueScore,
        processor: phones.processor,
        mainCamera: phones.mainCamera,
        batteryCapacity: phones.batteryCapacity,
        category: phones.category,
        releaseYear: phones.releaseYear,
        companyId: phones.companyId,
        companyNameAr: companies.nameAr,
      })
      .from(phones)
      .leftJoin(companies, eq(phones.companyId, companies.id))
      .$dynamic();

    const conditions = [];

    if (search) {
      conditions.push(
        or(
          like(phones.nameAr, `%${search}%`),
          like(phones.name, `%${search}%`),
          like(phones.slug, `%${search}%`),
          like(companies.nameAr, `%${search}%`),
          like(companies.name, `%${search}%`)
        )!
      );
    }

    if (category) {
      conditions.push(eq(phones.category, category));
    }

    if (company) {
      const companyCondition = or(
        like(companies.name, `%${company}%`),
        like(companies.nameAr, `%${company}%`)
      );
      if (companyCondition) conditions.push(companyCondition);
    }

    if (minPrice) {
      conditions.push(gte(phones.priceUsd, minPrice));
    }

    if (maxPrice) {
      conditions.push(lte(phones.priceUsd, maxPrice));
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    // Sorting
    switch (sortBy) {
      case "price_low":
        query = query.orderBy(sql`${phones.priceUsd} ASC NULLS LAST`);
        break;
      case "price_high":
        query = query.orderBy(sql`${phones.priceUsd} DESC NULLS LAST`);
        break;
      case "rating":
        query = query.orderBy(sql`${phones.overallScore} DESC NULLS LAST`);
        break;
      case "newest":
      default:
        query = query.orderBy(desc(phones.releaseYear), desc(phones.id));
        break;
    }

    const results = await query.limit(limit).offset(offset);

    // Get total count
    const countResult = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(phones)
      .leftJoin(companies, eq(phones.companyId, companies.id));

    return NextResponse.json({
      phones: results,
      total: countResult[0]?.count || 0,
      limit,
      offset,
    });
  } catch (error) {
    console.error("Error fetching phones:", error);
    return NextResponse.json({ error: "فشل في جلب الهواتف" }, { status: 500 });
  }
}
