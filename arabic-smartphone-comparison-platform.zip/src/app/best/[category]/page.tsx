import { db } from "@/db";
import { phones, companies } from "@/db/schema";
import { eq, lte, desc, sql } from "drizzle-orm";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import PhoneCard from "@/components/PhoneCard";
import Link from "next/link";
import type { Metadata } from "next";

interface BestPhonesPageProps {
  params: Promise<{ category: string }>;
}

const categoryInfo: Record<string, { title: string; icon: string; description: string }> = {
  flagship: { title: "أفضل الهواتف الرائدة", icon: "👑", description: "أقوى الهواتف وأكثرها تميزاً في السوق" },
  gaming: { title: "أفضل هواتف الألعاب", icon: "🎮", description: "هواتف بأداء خارق لتجربة لعب سلسة" },
  camera: { title: "أفضل هواتف التصوير", icon: "📷", description: "هواتف بكاميرات استثنائية لالتقاط أجمل اللحظات" },
  battery: { title: "أفضل هواتف البطارية", icon: "🔋", description: "هواتف ببطاريات تدوم طوال اليوم وأكثر" },
  midrange: { title: "أفضل الهواتف المتوسطة", icon: "📊", description: "هواتف بمواصفات رائعة وأسعار معقولة" },
  budget: { title: "أفضل الهواتف الاقتصادية", icon: "💰", description: "هواتف بسعر منخفض وقيمة ممتازة" },
  "budget-200": { title: "أفضل الهواتف تحت 200 دولار", icon: "💵", description: "خيارات ممتازة بميزانية محدودة" },
  "budget-300": { title: "أفضل الهواتف تحت 300 دولار", icon: "💵", description: "هواتف اقتصادية بمواصفات جيدة" },
  "budget-500": { title: "أفضل الهواتف تحت 500 دولار", icon: "💵", description: "هواتف متوسطة ورائدة بأسعار معقولة" },
  "budget-700": { title: "أفضل الهواتف تحت 700 دولار", icon: "💵", description: "هواتف شبه رائدة بأسعار ممتازة" },
};

export async function generateMetadata({ params }: BestPhonesPageProps): Promise<Metadata> {
  const { category } = await params;
  const info = categoryInfo[category] || { title: "أفضل الهواتف", description: "" };
  return {
    title: `${info.title} | مقارن`,
    description: info.description,
  };
}

export default async function BestPhonesPage({ params }: BestPhonesPageProps) {
  const { category } = await params;
  const info = categoryInfo[category] || { title: "أفضل الهواتف", icon: "📱", description: "" };

  let conditions: any[] = [];
  let orderBy: any = desc(phones.overallScore);

  if (category.startsWith("budget-")) {
    const price = category.replace("budget-", "");
    conditions.push(lte(phones.priceUsd, price));
    orderBy = desc(phones.valueScore);
  } else {
    conditions.push(eq(phones.category, category));
    if (category === "gaming") orderBy = desc(phones.performanceScore);
    if (category === "camera") orderBy = desc(phones.cameraScore);
    if (category === "battery") orderBy = desc(phones.batteryScore);
    if (category === "budget") orderBy = desc(phones.valueScore);
  }

  const whereClause = conditions.length > 0
    ? sql`${sql.join(conditions.map(c => sql`(${c})`), sql` AND `)}`
    : undefined;

  const results = await db
    .select({
      id: phones.id,
      nameAr: phones.nameAr,
      slug: phones.slug,
      image: phones.image,
      priceUsd: phones.priceUsd,
      priceSar: phones.priceSar,
      overallScore: phones.overallScore,
      performanceScore: phones.performanceScore,
      cameraScore: phones.cameraScore,
      batteryScore: phones.batteryScore,
      displayScore: phones.displayScore,
      valueScore: phones.valueScore,
      processor: phones.processor,
      mainCamera: phones.mainCamera,
      batteryCapacity: phones.batteryCapacity,
      category: phones.category,
      companyId: phones.companyId,
    })
    .from(phones)
    .where(whereClause)
    .orderBy(orderBy)
    .limit(20);

  const companyIds = [...new Set(results.map((p) => p.companyId))];
  const companiesData = companyIds.length > 0
    ? await db.select().from(companies).where(sql`${companies.id} IN (${sql.join(companyIds.map((id) => sql`${id}`), sql`, `)})`)
    : [];
  const companyMap = Object.fromEntries(companiesData.map((c) => [c.id, c]));

  // If no results from specific category, fallback to top-rated
  let displayPhones = results;
  if (results.length === 0) {
    displayPhones = await db
      .select({
        id: phones.id,
        nameAr: phones.nameAr,
        slug: phones.slug,
        image: phones.image,
        priceUsd: phones.priceUsd,
        priceSar: phones.priceSar,
        overallScore: phones.overallScore,
        performanceScore: phones.performanceScore,
        cameraScore: phones.cameraScore,
        batteryScore: phones.batteryScore,
        displayScore: phones.displayScore,
        valueScore: phones.valueScore,
        processor: phones.processor,
        mainCamera: phones.mainCamera,
        batteryCapacity: phones.batteryCapacity,
        category: phones.category,
        companyId: phones.companyId,
      })
      .from(phones)
      .orderBy(desc(phones.overallScore))
      .limit(20);
  }

  return (
    <>
      <Navbar />
      <main className="flex-1">
        {/* Header */}
        <div className="bg-gradient-to-br from-primary-50 via-white to-purple-50 border-b border-gray-100">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
            <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
              <Link href="/" className="hover:text-primary-600">الرئيسية</Link>
              <span>/</span>
              <span className="text-gray-900">{info.title}</span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-extrabold text-gray-900 mb-2">
              {info.icon} {info.title}
            </h1>
            <p className="text-gray-500">{info.description}</p>
          </div>
        </div>

        {/* Category Tabs */}
        <div className="bg-white border-b border-gray-100 sticky top-16 z-30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <div className="flex overflow-x-auto gap-1 py-2 scrollbar-hide">
              {Object.entries(categoryInfo).map(([key, val]) => (
                <Link
                  key={key}
                  href={`/best/${key}`}
                  className={`shrink-0 text-xs font-medium px-3 py-2 rounded-lg transition-colors ${
                    key === category
                      ? "bg-primary-100 text-primary-700"
                      : "text-gray-500 hover:bg-gray-50"
                  }`}
                >
                  {val.icon} {val.title.replace("أفضل ", "")}
                </Link>
              ))}
            </div>
          </div>
        </div>

        {/* Phone List */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
          {displayPhones.length === 0 ? (
            <div className="text-center py-16">
              <span className="text-5xl mb-4 block">📱</span>
              <h3 className="text-lg font-bold text-gray-900 mb-2">لا توجد هواتف في هذه الفئة حالياً</h3>
              <p className="text-sm text-gray-500">جرب تصفح فئة أخرى</p>
            </div>
          ) : (
            <>
              {/* Top 3 */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-8">
                {displayPhones.slice(0, 3).map((phone, i) => (
                  <Link key={phone.id} href={`/phones/${phone.slug}`}>
                    <div className="card-hover bg-white rounded-2xl border border-gray-100 overflow-hidden relative">
                      {i === 0 && (
                        <div className="absolute top-3 right-3 bg-amber-400 text-amber-900 text-[10px] font-extrabold px-2 py-1 rounded-full">
                          🥇 المركز الأول
                        </div>
                      )}
                      {i === 1 && (
                        <div className="absolute top-3 right-3 bg-gray-300 text-gray-700 text-[10px] font-extrabold px-2 py-1 rounded-full">
                          🥈 المركز الثاني
                        </div>
                      )}
                      {i === 2 && (
                        <div className="absolute top-3 right-3 bg-amber-600 text-white text-[10px] font-extrabold px-2 py-1 rounded-full">
                          🥉 المركز الثالث
                        </div>
                      )}
                      <div className="h-40 bg-gradient-to-br from-primary-50 via-purple-50 to-pink-50 flex items-center justify-center">
                        <span className="text-5xl">📱</span>
                      </div>
                      <div className="p-4">
                        {companyMap[phone.companyId] && (
                          <p className="text-xs text-primary-500 font-medium">{companyMap[phone.companyId].nameAr}</p>
                        )}
                        <h3 className="text-sm font-bold text-gray-900 mb-2">{phone.nameAr}</h3>
                        {phone.overallScore && (
                          <div className="flex items-center gap-2 mb-2">
                            <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden">
                              <div
                                className={`h-full rounded-full ${phone.overallScore >= 90 ? "bg-green-500" : phone.overallScore >= 80 ? "bg-lime-500" : "bg-yellow-500"}`}
                                style={{ width: `${phone.overallScore}%` }}
                              />
                            </div>
                            <span className="text-xs font-bold text-gray-700">{phone.overallScore}/100</span>
                          </div>
                        )}
                        {phone.priceUsd && (
                          <span className="text-lg font-bold text-gray-900">${phone.priceUsd}</span>
                        )}
                      </div>
                    </div>
                  </Link>
                ))}
              </div>

              {/* Rest */}
              {displayPhones.length > 3 && (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  {displayPhones.slice(3).map((phone) => (
                    <PhoneCard
                      key={phone.id}
                      phone={phone}
                      company={
                        companyMap[phone.companyId]
                          ? { nameAr: companyMap[phone.companyId].nameAr }
                          : undefined
                      }
                    />
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </main>
      <Footer />
    </>
  );
}
