import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import AiChat from "@/components/AiChat";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "المساعد الذكي | مقارن",
  description: "مساعد ذكاء اصطناعي يساعدك على اختيار الهاتف المناسب بناءً على احتياجاتك وميزانيتك",
};

export default function AiAssistantPage() {
  return (
    <>
      <Navbar />
      <main className="flex-1">
        <div className="bg-gradient-to-br from-primary-600 via-primary-700 to-purple-800 text-white">
          <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8 text-center">
            <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 2a8 8 0 0 0-8 8c0 3.4 2.1 6.3 5 7.5V20h6v-2.5c2.9-1.2 5-4.1 5-7.5a8 8 0 0 0-8-8z"/>
                <line x1="9" y1="23" x2="15" y2="23"/>
              </svg>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold mb-2">المساعد الذكي</h1>
            <p className="text-primary-100">
              أخبرني بما تحتاج وسأساعدك في العثور على الهاتف المثالي
            </p>
          </div>
        </div>

        <div className="max-w-3xl mx-auto px-4 sm:px-6 -mt-4">
          <div className="bg-white rounded-2xl border border-gray-200 shadow-xl shadow-gray-200/50 overflow-hidden min-h-[500px] flex flex-col">
            <AiChat />
          </div>
        </div>

        {/* How it works */}
        <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12">
          <h2 className="text-lg font-bold text-gray-900 mb-4 text-center">كيف يعمل المساعد الذكي؟</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white rounded-xl border border-gray-100 p-4 text-center">
              <span className="text-3xl mb-2 block">💬</span>
              <h3 className="text-sm font-bold text-gray-900 mb-1">اكتب طلبك</h3>
              <p className="text-xs text-gray-500">اكتب ما تحتاج بلغتك، مثل &quot;أريد هاتف للألعاب بسعر 300 دولار&quot;</p>
            </div>
            <div className="bg-white rounded-xl border border-gray-100 p-4 text-center">
              <span className="text-3xl mb-2 block">🧠</span>
              <h3 className="text-sm font-bold text-gray-900 mb-1">تحليل ذكي</h3>
              <p className="text-xs text-gray-500">يحلل طلبك ويفهم احتياجاتك وميزانيتك</p>
            </div>
            <div className="bg-white rounded-xl border border-gray-100 p-4 text-center">
              <span className="text-3xl mb-2 block">📱</span>
              <h3 className="text-sm font-bold text-gray-900 mb-1">توصيات مخصصة</h3>
              <p className="text-xs text-gray-500">يرشح لك أفضل الهواتف مع شرح سبب الترشيح</p>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
