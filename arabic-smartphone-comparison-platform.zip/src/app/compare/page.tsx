"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

interface PhoneOption {
  id: number;
  nameAr: string;
  slug: string;
  priceUsd: string | null;
  overallScore: number | null;
  companyNameAr: string | null;
}

interface PhoneDetail {
  id: number;
  nameAr: string;
  slug: string;
  priceUsd: string | null;
  priceSar: string | null;
  overallScore: number | null;
  performanceScore: number | null;
  cameraScore: number | null;
  batteryScore: number | null;
  displayScore: number | null;
  valueScore: number | null;
  processor: string | null;
  ram: string | null;
  storage: string | null;
  displaySize: string | null;
  displayType: string | null;
  displayResolution: string | null;
  refreshRate: string | null;
  batteryCapacity: string | null;
  chargingSpeed: string | null;
  mainCamera: string | null;
  selfieCamera: string | null;
  os: string | null;
  weight: string | null;
  nfc: boolean | null;
  waterResistance: string | null;
  fiveG: boolean | null;
  companyNameAr: string | null;
}

function getScoreBg(score: number | null): string {
  if (!score) return "";
  if (score >= 90) return "bg-green-50 border-green-200";
  if (score >= 80) return "bg-lime-50 border-lime-200";
  if (score >= 70) return "bg-yellow-50 border-yellow-200";
  return "bg-red-50 border-red-200";
}

export default function ComparePage() {
  const [allPhones, setAllPhones] = useState<PhoneOption[]>([]);
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const [compareData, setCompareData] = useState<PhoneDetail[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    fetch("/api/phones?limit=50")
      .then((r) => r.json())
      .then((data) => setAllPhones(data.phones || []))
      .catch(console.error);
  }, []);

  useEffect(() => {
    if (selectedIds.length >= 2) {
      doCompare();
    } else {
      setCompareData([]);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedIds]);

  const doCompare = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/compare", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phoneIds: selectedIds }),
      });
      const data = await res.json();
      setCompareData(data.phones || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const togglePhone = (id: number) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter((i) => i !== id));
    } else if (selectedIds.length < 4) {
      setSelectedIds([...selectedIds, id]);
    }
  };

  const filtered = allPhones.filter(
    (p) =>
      p.nameAr.includes(searchTerm) ||
      (p.companyNameAr && p.companyNameAr.includes(searchTerm))
  );

  const specRows: { label: string; key: keyof PhoneDetail; isScore?: boolean }[] = [
    { label: "السعر", key: "priceUsd" },
    { label: "التقييم العام", key: "overallScore", isScore: true },
    { label: "الأداء", key: "performanceScore", isScore: true },
    { label: "الكاميرا", key: "cameraScore", isScore: true },
    { label: "البطارية", key: "batteryScore", isScore: true },
    { label: "الشاشة", key: "displayScore", isScore: true },
    { label: "القيمة", key: "valueScore", isScore: true },
    { label: "المعالج", key: "processor" },
    { label: "الرام", key: "ram" },
    { label: "التخزين", key: "storage" },
    { label: "حجم الشاشة", key: "displaySize" },
    { label: "نوع الشاشة", key: "displayType" },
    { label: "دقة الشاشة", key: "displayResolution" },
    { label: "معدل التحديث", key: "refreshRate" },
    { label: "سعة البطارية", key: "batteryCapacity" },
    { label: "سرعة الشحن", key: "chargingSpeed" },
    { label: "الكاميرا الخلفية", key: "mainCamera" },
    { label: "الكاميرا الأمامية", key: "selfieCamera" },
    { label: "نظام التشغيل", key: "os" },
    { label: "الوزن", key: "weight" },
    { label: "مقاومة الماء", key: "waterResistance" },
  ];

  return (
    <>
      <Navbar />
      <main className="flex-1">
        <div className="bg-gradient-to-br from-primary-50 via-white to-purple-50 border-b border-gray-100">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900 mb-2">⚖️ مقارنة الهواتف</h1>
            <p className="text-gray-500">اختر 2 إلى 4 هواتف للمقارنة</p>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
          {/* Phone Selection */}
          <div className="bg-white rounded-2xl border border-gray-100 p-6 mb-8">
            <div className="mb-4">
              <input
                type="text"
                placeholder="ابحث عن هاتف لإضافته للمقارنة..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full h-11 px-4 text-sm rounded-xl border border-gray-200 bg-gray-50 focus:bg-white focus:border-primary-400 focus:outline-none focus:ring-2 focus:ring-primary-100"
              />
            </div>

            {/* Selected Phones */}
            <div className="flex flex-wrap gap-2 mb-4">
              {selectedIds.length === 0 && (
                <span className="text-sm text-gray-400">لم تختر أي هاتف بعد</span>
              )}
              {selectedIds.map((id) => {
                const phone = allPhones.find((p) => p.id === id);
                if (!phone) return null;
                return (
                  <span
                    key={id}
                    className="inline-flex items-center gap-1.5 bg-primary-50 text-primary-700 text-sm font-medium px-3 py-1.5 rounded-full"
                  >
                    {phone.nameAr}
                    <button onClick={() => togglePhone(id)} className="hover:text-primary-900">✕</button>
                  </span>
                );
              })}
            </div>

            {/* Phone Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2 max-h-64 overflow-y-auto">
              {filtered.map((phone) => {
                const isSelected = selectedIds.includes(phone.id);
                return (
                  <button
                    key={phone.id}
                    onClick={() => togglePhone(phone.id)}
                    disabled={!isSelected && selectedIds.length >= 4}
                    className={`p-3 rounded-xl border text-right transition-all ${
                      isSelected
                        ? "border-primary-400 bg-primary-50 ring-2 ring-primary-200"
                        : "border-gray-100 hover:border-primary-200 hover:bg-gray-50 disabled:opacity-40"
                    }`}
                  >
                    <p className="text-xs font-semibold text-gray-900 truncate">{phone.nameAr}</p>
                    {phone.companyNameAr && (
                      <p className="text-[10px] text-gray-400">{phone.companyNameAr}</p>
                    )}
                    {phone.priceUsd && (
                      <p className="text-[10px] text-primary-600 font-bold">${phone.priceUsd}</p>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Comparison Table */}
          {loading && (
            <div className="text-center py-12">
              <div className="w-8 h-8 border-2 border-primary-400 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
              <p className="text-sm text-gray-500">جاري المقارنة...</p>
            </div>
          )}

          {!loading && compareData.length >= 2 && (
            <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-100">
                      <th className="px-4 py-3 text-sm font-medium text-gray-500 text-right bg-gray-50 w-40 shrink-0">
                        المواصفة
                      </th>
                      {compareData.map((phone) => (
                        <th key={phone.id} className="px-4 py-3 text-center min-w-[180px]">
                          <Link href={`/phones/${phone.slug}`} className="hover:text-primary-600">
                            <p className="text-sm font-bold text-gray-900">{phone.nameAr}</p>
                            {phone.companyNameAr && (
                              <p className="text-[10px] text-gray-400">{phone.companyNameAr}</p>
                            )}
                          </Link>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {specRows.map((row, i) => {
                      const values = compareData.map((p) => p[row.key]);
                      const hasValues = values.some((v) => v !== null && v !== undefined);

                      if (!hasValues) return null;

                      // Find best score for highlighting
                      let bestIdx = -1;
                      if (row.isScore) {
                        const numValues = values.map((v) =>
                          typeof v === "number" ? v : 0
                        );
                        bestIdx = numValues.indexOf(Math.max(...numValues));
                      }

                      return (
                        <tr key={i} className={i % 2 === 0 ? "bg-white" : "bg-gray-50/50"}>
                          <td className="px-4 py-3 text-xs font-medium text-gray-500">
                            {row.label}
                          </td>
                          {compareData.map((phone, j) => {
                            const val = phone[row.key];
                            const isBest = j === bestIdx && bestIdx !== -1;
                            return (
                              <td
                                key={phone.id}
                                className={`px-4 py-3 text-center text-sm ${
                                  isBest
                                    ? "font-bold text-green-600 bg-green-50/50"
                                    : "text-gray-700"
                                }`}
                              >
                                {row.isScore && typeof val === "number"
                                  ? `${val}/100`
                                  : val === null || val === undefined
                                  ? "—"
                                  : row.key === "priceUsd"
                                  ? `$${val}`
                                  : String(val)}
                              </td>
                            );
                          })}
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {!loading && selectedIds.length < 2 && (
            <div className="text-center py-16">
              <span className="text-6xl mb-4 block">⚖️</span>
              <h3 className="text-lg font-bold text-gray-900 mb-2">اختر هاتفين على الأقل للمقارنة</h3>
              <p className="text-sm text-gray-500">يمكنك مقارنة حتى 4 هواتف في نفس الوقت</p>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </>
  );
}
