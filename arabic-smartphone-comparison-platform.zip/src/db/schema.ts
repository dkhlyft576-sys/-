import {
  pgTable,
  serial,
  integer,
  varchar,
  text,
  decimal,
  timestamp,
  boolean,
  jsonb,
  index,
} from "drizzle-orm/pg-core";

// Companies
export const companies = pgTable("companies", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  nameAr: varchar("name_ar", { length: 100 }).notNull(),
  logo: text("logo"),
  country: varchar("country", { length: 100 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Phones
export const phones = pgTable(
  "phones",
  {
    id: serial("id").primaryKey(),
    companyId: integer("company_id")
      .references(() => companies.id)
      .notNull(),
    name: varchar("name", { length: 200 }).notNull(),
    nameAr: varchar("name_ar", { length: 200 }).notNull(),
    slug: varchar("slug", { length: 250 }).notNull().unique(),
    image: text("image"),
    releaseYear: integer("release_year"),
    priceUsd: decimal("price_usd", { precision: 10, scale: 2 }),
    priceSar: decimal("price_sar", { precision: 10, scale: 2 }),
    priceAed: decimal("price_aed", { precision: 10, scale: 2 }),

    // Scores (0-100)
    overallScore: integer("overall_score"),
    performanceScore: integer("performance_score"),
    cameraScore: integer("camera_score"),
    batteryScore: integer("battery_score"),
    displayScore: integer("display_score"),
    valueScore: integer("value_score"),

    // Content
    descriptionAr: text("description_ar"),
    reviewAr: text("review_ar"),
    prosAr: jsonb("pros_ar").$type<string[]>(),
    consAr: jsonb("cons_ar").$type<string[]>(),

    // Specifications
    processor: varchar("processor", { length: 200 }),
    ram: varchar("ram", { length: 50 }),
    storage: varchar("storage", { length: 100 }),
    displaySize: varchar("display_size", { length: 50 }),
    displayType: varchar("display_type", { length: 200 }),
    displayResolution: varchar("display_resolution", { length: 100 }),
    refreshRate: varchar("refresh_rate", { length: 50 }),
    batteryCapacity: varchar("battery_capacity", { length: 50 }),
    chargingSpeed: varchar("charging_speed", { length: 50 }),
    mainCamera: varchar("main_camera", { length: 200 }),
    selfieCamera: varchar("selfie_camera", { length: 100 }),
    os: varchar("os", { length: 100 }),
    weight: varchar("weight", { length: 50 }),
    dimensions: varchar("dimensions", { length: 100 }),
    nfc: boolean("nfc").default(false),
    waterResistance: varchar("water_resistance", { length: 50 }),
    fingerprint: varchar("fingerprint", { length: 100 }),
    simType: varchar("sim_type", { length: 50 }),
    fiveG: boolean("five_g").default(false),

    category: varchar("category", { length: 50 }), // gaming, camera, battery, flagship, midrange, budget

    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (table) => [
    index("phones_company_id_idx").on(table.companyId),
    index("phones_slug_idx").on(table.slug),
    index("phones_category_idx").on(table.category),
    index("phones_price_usd_idx").on(table.priceUsd),
  ]
);

// Phone Images
export const phoneImages = pgTable("phone_images", {
  id: serial("id").primaryKey(),
  phoneId: integer("phone_id")
    .references(() => phones.id, { onDelete: "cascade" })
    .notNull(),
  url: text("url").notNull(),
  alt: varchar("alt", { length: 200 }),
  sortOrder: integer("sort_order").default(0),
});

// Articles
export const articles = pgTable("articles", {
  id: serial("id").primaryKey(),
  titleAr: varchar("title_ar", { length: 300 }).notNull(),
  contentAr: text("content_ar").notNull(),
  slug: varchar("slug", { length: 300 }).notNull().unique(),
  image: text("image"),
  category: varchar("category", { length: 50 }),
  published: boolean("published").default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Comments
export const comments = pgTable("comments", {
  id: serial("id").primaryKey(),
  phoneId: integer("phone_id")
    .references(() => phones.id, { onDelete: "cascade" })
    .notNull(),
  authorName: varchar("author_name", { length: 100 }).notNull(),
  content: text("content").notNull(),
  rating: integer("rating"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Saved Comparisons
export const comparisons = pgTable("comparisons", {
  id: serial("id").primaryKey(),
  phoneIds: jsonb("phone_ids").$type<number[]>().notNull(),
  viewCount: integer("view_count").default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
