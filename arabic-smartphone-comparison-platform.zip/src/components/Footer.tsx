import Link from "next/link";

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 bg-gradient-to-br from-primary-400 to-primary-600 rounded-xl flex items-center justify-center">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="5" y="2" width="14" height="20" rx="2" ry="2"/>
                  <line x1="12" y1="18" x2="12" y2="18.01"/>
                </svg>
              </div>
              <span className="text-xl font-bold text-white">مقارن</span>
            </div>
            <p className="text-sm text-gray-400 leading-relaxed">
              منصة عربية ذكية لمقارنة الهواتف الذكية ومساعدتك على اختيار الهاتف المناسب لاحتياجاتك وميزانيتك.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white font-semibold mb-4">روابط سريعة</h3>
            <ul className="space-y-2">
              <li><Link href="/" className="text-sm hover:text-primary-400 transition-colors">الرئيسية</Link></li>
              <li><Link href="/compare" className="text-sm hover:text-primary-400 transition-colors">مقارنة الهواتف</Link></li>
              <li><Link href="/ai-assistant" className="text-sm hover:text-primary-400 transition-colors">المساعد الذكي</Link></li>
              <li><Link href="/search" className="text-sm hover:text-primary-400 transition-colors">البحث المتقدم</Link></li>
            </ul>
          </div>

          {/* Best Phones */}
          <div>
            <h3 className="text-white font-semibold mb-4">أفضل الهواتف</h3>
            <ul className="space-y-2">
              <li><Link href="/best/flagship" className="text-sm hover:text-primary-400 transition-colors">أفضل الهواتف الرائدة</Link></li>
              <li><Link href="/best/gaming" className="text-sm hover:text-primary-400 transition-colors">أفضل هواتف الألعاب</Link></li>
              <li><Link href="/best/camera" className="text-sm hover:text-primary-400 transition-colors">أفضل هواتف التصوير</Link></li>
              <li><Link href="/best/budget" className="text-sm hover:text-primary-400 transition-colors">أفضل الهواتف الاقتصادية</Link></li>
              <li><Link href="/best/battery" className="text-sm hover:text-primary-400 transition-colors">أفضل بطارية</Link></li>
            </ul>
          </div>

          {/* Budget */}
          <div>
            <h3 className="text-white font-semibold mb-4">حسب الميزانية</h3>
            <ul className="space-y-2">
              <li><Link href="/best/budget-200" className="text-sm hover:text-primary-400 transition-colors">أقل من 200 دولار</Link></li>
              <li><Link href="/best/budget-300" className="text-sm hover:text-primary-400 transition-colors">أقل من 300 دولار</Link></li>
              <li><Link href="/best/budget-500" className="text-sm hover:text-primary-400 transition-colors">أقل من 500 دولار</Link></li>
              <li><Link href="/best/budget-700" className="text-sm hover:text-primary-400 transition-colors">أقل من 700 دولار</Link></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm text-gray-500">© 2024 مقارن. جميع الحقوق محفوظة.</p>
          <div className="flex items-center gap-4">
            <span className="text-xs text-gray-600">منصة عربية ذكية لمقارنة الهواتف</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
