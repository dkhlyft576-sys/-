interface RatingBarProps {
  label: string;
  score: number | null;
  maxScore?: number;
}

function getScoreColor(score: number): string {
  if (score >= 90) return "bg-green-500";
  if (score >= 80) return "bg-lime-500";
  if (score >= 70) return "bg-yellow-500";
  return "bg-red-500";
}

function getScoreTextColor(score: number): string {
  if (score >= 90) return "text-green-600";
  if (score >= 80) return "text-lime-600";
  if (score >= 70) return "text-yellow-600";
  return "text-red-600";
}

function getLabel(score: number): string {
  if (score >= 90) return "ممتاز";
  if (score >= 80) return "جيد جداً";
  if (score >= 70) return "جيد";
  if (score >= 60) return "مقبول";
  return "ضعيف";
}

export default function RatingBar({ label, score, maxScore = 100 }: RatingBarProps) {
  if (score === null) return null;
  const percentage = (score / maxScore) * 100;

  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between">
        <span className="text-sm text-gray-600">{label}</span>
        <div className="flex items-center gap-2">
          <span className={`text-[10px] font-medium ${getScoreTextColor(score)}`}>
            {getLabel(score)}
          </span>
          <span className={`text-sm font-bold ${getScoreTextColor(score)}`}>{score}</span>
        </div>
      </div>
      <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
        <div
          className={`h-full rounded-full transition-all duration-700 ${getScoreColor(score)}`}
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
}
