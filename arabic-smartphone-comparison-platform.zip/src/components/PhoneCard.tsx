import Link from "next/link";

interface PhoneCardProps {
  phone: {
    id: number;
    nameAr: string;
    slug: string;
    image: string | null;
    priceUsd: string | null;
    priceSar: string | null;
    overallScore: number | null;
    category: string | null;
    processor: string | null;
    mainCamera: string | null;
    batteryCapacity: string | null;
  };
  company?: {
    nameAr: string;
  };
  compact?: boolean;
}

function getScoreColor(score: number | null): string {
  if (!score) return "text-gray-400";
  if (score >= 90) return "text-green-500";
  if (score >= 80) return "text-lime-500";
  if (score >= 70) return "text-yellow-500";
  return "text-red-500";
}

function getScoreBg(score: number | null): string {
  if (!score) return "bg-gray-100";
  if (score >= 90) return "bg-green-50 border-green-200";
  if (score >= 80) return "bg-lime-50 border-lime-200";
  if (score >= 70) return "bg-yellow-50 border-yellow-200";
  return "bg-red-50 border-red-200";
}

function getCategoryLabel(cat: string | null): string {
  const map: Record<string, string> = {
    flagship: "رائد",
    midrange: "متوسط",
    budget: "اقتصادي",
    gaming: "ألعاب",
    camera: "تصوير",
    battery: "بطارية",
  };
  return cat ? map[cat] || cat : "";
}

function getCategoryColor(cat: string | null): string {
  const map: Record<string, string> = {
    flagship: "bg-purple-100 text-purple-700",
    midrange: "bg-blue-100 text-blue-700",
    budget: "bg-green-100 text-green-700",
    gaming: "bg-red-100 text-red-700",
    camera: "bg-amber-100 text-amber-700",
    battery: "bg-teal-100 text-teal-700",
  };
  return cat ? map[cat] || "bg-gray-100 text-gray-700" : "bg-gray-100 text-gray-700";
}

export default function PhoneCard({ phone, company, compact = false }: PhoneCardProps) {
  if (compact) {
    return (
      <Link href={`/phones/${phone.slug}`} className="block">
        <div className="card-hover bg-white rounded-xl border border-gray-100 p-4 flex items-center gap-4">
          <div className="w-16 h-16 bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg flex items-center justify-center shrink-0">
            {phone.image ? (
              <span className="text-2xl">📱</span>
            ) : (
              <span className="text-2xl">📱</span>
            )}
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="text-sm font-semibold text-gray-900 truncate">{phone.nameAr}</h3>
            {company && <p className="text-xs text-gray-500">{company.nameAr}</p>}
            <div className="flex items-center gap-3 mt-1">
              {phone.priceUsd && <span className="text-xs font-bold text-primary-600">${phone.priceUsd}</span>}
              {phone.overallScore && (
                <span className={`text-xs font-bold ${getScoreColor(phone.overallScore)}`}>
                  {phone.overallScore}/100
                </span>
              )}
            </div>
          </div>
        </div>
      </Link>
    );
  }

  return (
    <Link href={`/phones/${phone.slug}`} className="block">
      <div className="card-hover bg-white rounded-2xl border border-gray-100 overflow-hidden">
        {/* Image Area */}
        <div className="relative h-48 bg-gradient-to-br from-primary-50 via-purple-50 to-pink-50 flex items-center justify-center">
          <span className="text-6xl">📱</span>
          {phone.category && (
            <span className={`absolute top-3 right-3 text-[10px] font-bold px-2 py-1 rounded-full ${getCategoryColor(phone.category)}`}>
              {getCategoryLabel(phone.category)}
            </span>
          )}
          {phone.overallScore && (
            <div className={`absolute top-3 left-3 text-xs font-bold px-2 py-1 rounded-full border ${getScoreBg(phone.overallScore)} ${getScoreColor(phone.overallScore)}`}>
              {phone.overallScore}
            </div>
          )}
        </div>

        {/* Info */}
        <div className="p-4">
          <div className="mb-2">
            {company && <p className="text-xs text-primary-500 font-medium mb-0.5">{company.nameAr}</p>}
            <h3 className="text-sm font-bold text-gray-900 line-clamp-2">{phone.nameAr}</h3>
          </div>

          {/* Key Specs */}
          <div className="flex flex-wrap gap-1.5 mb-3">
            {phone.processor && (
              <span className="text-[10px] bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full">{phone.processor.split(" ").slice(0, 2).join(" ")}</span>
            )}
            {phone.batteryCapacity && (
              <span className="text-[10px] bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full">🔋 {phone.batteryCapacity}</span>
            )}
            {phone.mainCamera && (
              <span className="text-[10px] bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full">📷 {phone.mainCamera.split("+")[0].trim()}</span>
            )}
          </div>

          {/* Price */}
          {phone.priceUsd && (
            <div className="flex items-center justify-between border-t border-gray-50 pt-3">
              <div>
                <span className="text-lg font-bold text-gray-900">${phone.priceUsd}</span>
                {phone.priceSar && (
                  <span className="text-xs text-gray-400 mr-2">~{phone.priceSar} ر.س</span>
                )}
              </div>
              <span className="text-primary-500 text-xs font-medium">المزيد ←</span>
            </div>
          )}
        </div>
      </div>
    </Link>
  );
}
